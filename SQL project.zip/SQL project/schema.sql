-- Schema for Collaborative Moodboard
-- Enable extensions (run once per database)
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Users
CREATE TABLE IF NOT EXISTS app_user (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    display_name TEXT NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Boards
CREATE TABLE IF NOT EXISTS board (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID REFERENCES app_user(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Board membership / roles
CREATE TABLE IF NOT EXISTS board_member (
    board_id UUID REFERENCES board(id) ON DELETE CASCADE,
    user_id UUID REFERENCES app_user(id) ON DELETE CASCADE,
    role TEXT NOT NULL DEFAULT 'editor',
    PRIMARY KEY (board_id, user_id)
);

-- Items on a board
CREATE TYPE item_kind AS ENUM ('image', 'link', 'color', 'note');

CREATE TABLE IF NOT EXISTS board_item (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    board_id UUID REFERENCES board(id) ON DELETE CASCADE,
    created_by UUID REFERENCES app_user(id),
    kind item_kind NOT NULL,
    title TEXT,
    description TEXT,
    content_url TEXT,
    color_hex TEXT,
    meta JSONB DEFAULT '{}'::jsonb,
    pos_x REAL NOT NULL DEFAULT 0,
    pos_y REAL NOT NULL DEFAULT 0,
    rotation REAL NOT NULL DEFAULT 0,
    z_index INT NOT NULL DEFAULT 0,
    embedding vector(64),
    search_tsv tsvector,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Search index
CREATE INDEX IF NOT EXISTS board_item_search_tsv_idx ON board_item USING GIN (search_tsv);

-- Vector index (tune lists per data size)
CREATE INDEX IF NOT EXISTS board_item_embedding_idx ON board_item USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Trigger to keep search vector updated
CREATE OR REPLACE FUNCTION board_item_tsv_trigger() RETURNS trigger AS $$
BEGIN
  NEW.search_tsv :=
    setweight(to_tsvector('english', coalesce(NEW.title, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(NEW.description, '')), 'B');
  NEW.updated_at := now();
  RETURN NEW;
END
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_board_item_tsv ON board_item;
CREATE TRIGGER trg_board_item_tsv BEFORE INSERT OR UPDATE
  ON board_item FOR EACH ROW EXECUTE FUNCTION board_item_tsv_trigger();

-- Sample seed
INSERT INTO app_user (id, display_name, avatar_url) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Ava Rivera', 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39'),
  ('00000000-0000-0000-0000-000000000002', 'Noah Singh', 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1')
ON CONFLICT DO NOTHING;

INSERT INTO board (id, owner_id, title, description) VALUES
  ('10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'Cinematic Desert', 'Sun-bleached dunes with neon accents'),
  ('10000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002', 'Nordic Calm', 'Fjords, fog, and soft gradients')
ON CONFLICT DO NOTHING;

INSERT INTO board_member (board_id, user_id, role) VALUES
  ('10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'owner'),
  ('10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'editor'),
  ('10000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002', 'owner')
ON CONFLICT DO NOTHING;

-- Sample items (embedding will be null; backend can update)
INSERT INTO board_item (id, board_id, created_by, kind, title, description, content_url, color_hex, pos_x, pos_y, z_index, rotation)
VALUES
  ('20000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001',
   'image', 'Mirage Highway', 'Heat shimmer over asphalt', 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee', NULL, -120, -40, 1, -3),
  ('20000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
   'color', 'Desert Gold', 'Warm sand tone', NULL, '#d7b472', 80, 10, 2, 1.5),
  ('20000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002',
   'image', 'Foggy Fjord', 'Muted teal waters and cliffs', 'https://images.unsplash.com/photo-1505761671935-60b3a7427bad', NULL, -60, -30, 1, 0),
  ('20000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000002', 'note', 'Soft gradients', 'Pale blues, grays, add lilac accents', NULL, NULL, 100, 40, 3, -2);

